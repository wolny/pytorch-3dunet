from pathlib import Path

import torch

from pybio.spec import load_spec_and_kwargs
from tiktorch.server.exemplum import Exemplum

if __name__ == "__main__":
    spec_path = Path(__file__).parent / "../bioimage-io/UNet3DArabidopsisOvules.model.yaml"
    assert spec_path.exists()
    pybio_model = load_spec_and_kwargs(str(spec_path))


    exemplum = Exemplum(pybio_model=pybio_model, _devices=[torch.device("cuda")], warmstart=True)
    print(exemplum)
